﻿UPDATE Directors
SET psevdonime = 'Eistein'
WHERE director_name = 'Steven Hawkins'

