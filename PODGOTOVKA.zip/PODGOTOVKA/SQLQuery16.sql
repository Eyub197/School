﻿DELETE FROM  Directors
WHERE director_name = 'Steven King'