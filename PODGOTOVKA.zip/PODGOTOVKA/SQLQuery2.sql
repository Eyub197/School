﻿CREATE TABLE Directors
(
	id int IDENTITY(1,1) PRIMARY KEY,
	director_name VARCHAR(50) NULL,
	notes TEXT NULL
) ;