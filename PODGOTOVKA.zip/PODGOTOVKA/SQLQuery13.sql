﻿ALTER TABLE Directors
ADD psevdonime VARCHAR(50)