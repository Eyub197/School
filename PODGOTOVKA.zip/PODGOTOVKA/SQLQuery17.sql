﻿SELECT m.title
FROM Movies AS m
JOIN Directors AS d
ON m.director_id = d.id
WHERE psevdonime IS NOT NULL
ORDER BY director_name DESC