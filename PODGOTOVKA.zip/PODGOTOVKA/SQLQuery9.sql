﻿INSERT INTO Directors 
VALUES('Steven King', NULL),
('Steven Spelberg', NULL),
('Steven Segal', NULL),
('Steven Hawkins', NULL)