﻿CREATE TABLE Genres
(
	id int IDENTITY(1,1) PRIMARY KEY,
	genre_name VARCHAR(20) NULL,
	notes TEXT NULL
);
