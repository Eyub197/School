﻿INSERT INTO Categories
VALUES('16+', NULL),
('18+', NULL),
('21+', NULL)