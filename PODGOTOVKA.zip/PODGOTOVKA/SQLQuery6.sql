﻿CREATE TABLE Movies
(
	id INT IDENTITY(1, 1) PRIMARY KEY,
	title VARCHAR(50) NULL,
	director_id INT FOREIGN KEY REFERENCES Directors(id),
	copyright_year date NULL,
	length TIME NULL,
	genre_id INT FOREIGN KEY REFERENCES Genres(id),
	category_id INT FOREIGN KEY REFERENCES Categories(id),
	rating INT NULL,
	notes TEXT NULL
);