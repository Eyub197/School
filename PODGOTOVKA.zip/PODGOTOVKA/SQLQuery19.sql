﻿SELECT categorie_name, COUNT(m.title)
FROM Categories AS c
JOIN Movies AS m
ON  c.id = m.category_id
GROUP BY c.categorie_name