﻿INSERT INTO Genres
VALUES('Comedy', NULL),
('Tragedy', NULL),
('Drama', NULL),
('Horror', NULL),
('Science-fiction', NULL)