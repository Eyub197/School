﻿INSERT INTO Movies
VALUES('Game of nerves', 4, '1982-01-01', '01:20:00', 1, 3, 5, NULL),
('Star Wars', 2, '1985-02-03', '02:10:00', 5, 1, 5, NULL),
('2 men and 1/2', 3, '2009-04-05', '00:47:00', 3, 1, 4, NULL)
