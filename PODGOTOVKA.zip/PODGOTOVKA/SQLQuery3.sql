﻿CREATE TABLE Categories
(
	id int IDENTITY(1,1) PRIMARY KEY,
	categorie_name VARCHAR(50) NULL,
	notes TEXT NULL
);