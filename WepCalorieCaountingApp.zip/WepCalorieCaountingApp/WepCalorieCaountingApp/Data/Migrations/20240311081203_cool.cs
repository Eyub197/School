﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WepCalorieCaountingApp.Data.Migrations
{
    public partial class cool : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FoodEntery",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(nullable: true),
                    MealType = table.Column<string>(nullable: true),
                    CaloriesConsumed = table.Column<int>(nullable: false),
                    FoodItemId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FoodEntery", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FoodEntery_Food_FoodItemId",
                        column: x => x.FoodItemId,
                        principalTable: "Food",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_FoodEntery_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FoodEntery_FoodItemId",
                table: "FoodEntery",
                column: "FoodItemId");

            migrationBuilder.CreateIndex(
                name: "IX_FoodEntery_UserId",
                table: "FoodEntery",
                column: "UserId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FoodEntery");
        }
    }
}
