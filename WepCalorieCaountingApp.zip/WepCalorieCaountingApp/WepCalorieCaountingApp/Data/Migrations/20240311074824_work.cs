﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WepCalorieCaountingApp.Data.Migrations
{
    public partial class work : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
