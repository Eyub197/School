﻿public enum FoodType 
{
    healthly,
    unhealthly
}
