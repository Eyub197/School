﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;


namespace WepCalorieCaounterApp.Models
{
    public class FoodEntery
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public IdentityUser User { get; set; } 
        public string MealType { get; set; }
        public int CaloriesConsumed { get; set; }
        public int FoodItemId { get; set; }
        public Food FoodItem { get; set; }
    }
}
