﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using WepCalorieCaounterApp.Models;

namespace WepCalorieCaountingApp.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<WepCalorieCaounterApp.Models.Food> Food { get; set; }
        public DbSet<WepCalorieCaounterApp.Models.FoodEntery> FoodEntery { get; set; }
    }
}
