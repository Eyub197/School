﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WepCalorieCaounterApp.Models;
using WepCalorieCaountingApp.Data;

namespace WepCalorieCaountingApp.Controllers
{
    public class FoodEnteriesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FoodEnteriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: FoodEnteries
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.FoodEntery.Include(f => f.FoodItem).Include(f => f.User);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: FoodEnteries/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodEntery = await _context.FoodEntery
                .Include(f => f.FoodItem)
                .Include(f => f.User)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (foodEntery == null)
            {
                return NotFound();
            }

            return View(foodEntery);
        }

        // GET: FoodEnteries/Create
        public IActionResult Create()
        {
            ViewData["FoodItemId"] = new SelectList(_context.Food, "Id", "Id");
            ViewData["UserId"] = new SelectList(_context.Users, "Id", "Id");
            return View();
        }

        // POST: FoodEnteries/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,UserId,MealType,CaloriesConsumed,FoodItemId")] FoodEntery foodEntery)
        {
            if (ModelState.IsValid)
            {
                _context.Add(foodEntery);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FoodItemId"] = new SelectList(_context.Food, "Id", "Id", foodEntery.FoodItemId);
            ViewData["UserId"] = new SelectList(_context.Users, "Id", "Id", foodEntery.UserId);
            return View(foodEntery);
        }

        // GET: FoodEnteries/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodEntery = await _context.FoodEntery.FindAsync(id);
            if (foodEntery == null)
            {
                return NotFound();
            }
            ViewData["FoodItemId"] = new SelectList(_context.Food, "Id", "Id", foodEntery.FoodItemId);
            ViewData["UserId"] = new SelectList(_context.Users, "Id", "Id", foodEntery.UserId);
            return View(foodEntery);
        }

        // POST: FoodEnteries/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,UserId,MealType,CaloriesConsumed,FoodItemId")] FoodEntery foodEntery)
        {
            if (id != foodEntery.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(foodEntery);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FoodEnteryExists(foodEntery.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FoodItemId"] = new SelectList(_context.Food, "Id", "Id", foodEntery.FoodItemId);
            ViewData["UserId"] = new SelectList(_context.Users, "Id", "Id", foodEntery.UserId);
            return View(foodEntery);
        }

        // GET: FoodEnteries/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var foodEntery = await _context.FoodEntery
                .Include(f => f.FoodItem)
                .Include(f => f.User)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (foodEntery == null)
            {
                return NotFound();
            }

            return View(foodEntery);
        }

        // POST: FoodEnteries/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var foodEntery = await _context.FoodEntery.FindAsync(id);
            _context.FoodEntery.Remove(foodEntery);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FoodEnteryExists(int id)
        {
            return _context.FoodEntery.Any(e => e.Id == id);
        }
    }
}
