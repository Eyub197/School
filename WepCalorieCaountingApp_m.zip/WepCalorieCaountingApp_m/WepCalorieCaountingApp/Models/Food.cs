﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WepCalorieCaounterApp.Models
{
    public class Food
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Image_url { get; set; }
        public double Caloris_Per_100g { get; set; }
        public DateTime Created_at { get; set; }
        public DateTime Expires_at { get; set; }
        public FoodType Type { get; set; }
    }
}
