﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkateboardsProject.Presentation.Display
{
    public class Display: DeckPresentaion 
    {
        public BearingPresentaion bearingPresentaion = new BearingPresentaion();
        public BrandPresentaion brandPresentaion = new BrandPresentaion();
        public DeckPresentaion deckPresentaion = new DeckPresentaion();
        public   WheelPresentaion wheelPresentaion = new WheelPresentaion();

        private int closeOperationId = 6;
        public void Menu()
        {
            var operation = -1;
            do
            {
                ChooseMenu();
                operation = int.Parse(Console.ReadLine());
                switch (operation)
                {
                    case 1:
                        DeckInput();
                        break;
                    //case 2:
                    //    BrandInput();
                    //    break;
                    //case 3:
                    //    BearingInput();
                    //    break;
                    //case 4:
                    //    WheelInput();
                    //    break;
                    //default:
                    //    break;
                }
            } while (operation != closeOperationId);
        }

        public void ChooseMenu() 
        {
            Console.WriteLine(new string('-', 40));
            Console.WriteLine(new string(' ', 18) + "MENU" + new string(' ', 18));
            Console.WriteLine(new string('-', 40));
            Console.WriteLine("1. Decks");
            Console.WriteLine("2 Bearing");
            Console.WriteLine("3. Brands ");
            Console.WriteLine("4. Wheels");
            Console.WriteLine("5. Exit");   
        }
    }
}

