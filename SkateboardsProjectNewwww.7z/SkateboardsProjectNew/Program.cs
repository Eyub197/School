﻿using SkateboardsProject.Presentation;
using SkateboardsProject.Presentation.Display;
using System;

namespace SkateboardsProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Display display = new Display();
        }
    }
}
