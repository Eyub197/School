﻿using Business;
using Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1.moeto
{
    public partial class Form1 : Form
    {
        ProductBusiness productBusiness = new ProductBusiness();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }

        private void UpdateGrid()
        {
            dataGridView1.DataSource = productBusiness.GetAll();
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void ClearTextBoxes()
        {
            textBoxName.Text = "";
            textBoxPrice.Text = "0";
            textBoxStock.Text = "0";
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            var name = textBoxName.Text;
            decimal price = 0;
            decimal.TryParse(textBoxPrice.Text, out price);
            int stock = 0;
            int.TryParse(textBoxStock.Text, out stock);

            Product product = new Product();
            product.Name = name;
            product.Price = price;
            product.Stock = stock;

            productBusiness.Add(product);
            UpdateGrid();
            ClearTextBoxes();
        }

        private void UpdateTextboxes(int id) 
        {
            Product update = productBusiness.Get(id);      
        }
    }
}
